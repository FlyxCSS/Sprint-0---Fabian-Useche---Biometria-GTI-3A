package com.example.fuseriv.aplicacionandroidble;

// ------------------------------------------------------------------
// IMPORTS
// ------------------------------------------------------------------

import android.Manifest;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.le.BluetoothLeScanner;
import android.bluetooth.le.ScanCallback;
import android.bluetooth.le.ScanFilter;
import android.bluetooth.le.ScanResult;
import android.bluetooth.le.ScanSettings;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import java.util.ArrayList;
import java.util.List;

// ------------------------------------------------------------------
// MAIN ACTIVITY
// ------------------------------------------------------------------

public class MainActivity extends AppCompatActivity {

    private static final String ETIQUETA_LOG = ">>>>";

    private static final int CODIGO_PETICION_PERMISOS = 11223344;

    // Nombre que estamos anunciando desde la SparkFun
    private static final String NOMBRE_BEACON = "Fabian_GTI";

    private BluetoothAdapter bluetoothAdapter;

    private BluetoothLeScanner elEscanner;

    private ScanCallback callbackDelEscaneo = null;


    // ------------------------------------------------------------------
    // COMPROBAR PERMISOS
    // ------------------------------------------------------------------

    private boolean tengoPermisosBluetooth() {

        // Android 12 o superior
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {

            return ContextCompat.checkSelfPermission(
                    this,
                    Manifest.permission.BLUETOOTH_SCAN
            ) == PackageManager.PERMISSION_GRANTED

                    &&

                    ContextCompat.checkSelfPermission(
                            this,
                            Manifest.permission.BLUETOOTH_CONNECT
                    ) == PackageManager.PERMISSION_GRANTED;
        }

        // Android 11 o inferior
        return ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.ACCESS_FINE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED;
    }


    // ------------------------------------------------------------------
    // PEDIR PERMISOS
    // ------------------------------------------------------------------

    private void pedirPermisosBluetooth() {

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {

            ActivityCompat.requestPermissions(
                    this,
                    new String[]{
                            Manifest.permission.BLUETOOTH_SCAN,
                            Manifest.permission.BLUETOOTH_CONNECT
                    },
                    CODIGO_PETICION_PERMISOS
            );

        } else {

            ActivityCompat.requestPermissions(
                    this,
                    new String[]{
                            Manifest.permission.ACCESS_FINE_LOCATION
                    },
                    CODIGO_PETICION_PERMISOS
            );
        }
    }


    // ------------------------------------------------------------------
    // INICIALIZAR BLUETOOTH
    // ------------------------------------------------------------------

    private void inicializarBlueTooth() {

        Log.d(
                ETIQUETA_LOG,
                "inicializarBlueTooth(): empieza"
        );

        // Primero comprobamos permisos
        if (!tengoPermisosBluetooth()) {

            Log.d(
                    ETIQUETA_LOG,
                    "No tenemos permisos. Los pedimos."
            );

            pedirPermisosBluetooth();

            return;
        }

        // Obtenemos adaptador Bluetooth
        bluetoothAdapter = BluetoothAdapter.getDefaultAdapter();

        if (bluetoothAdapter == null) {

            Log.d(
                    ETIQUETA_LOG,
                    "ERROR: este dispositivo no dispone de Bluetooth"
            );

            return;
        }

        // Comprobamos si Bluetooth está encendido
        if (!bluetoothAdapter.isEnabled()) {

            Log.d(
                    ETIQUETA_LOG,
                    "Bluetooth está DESACTIVADO. Actívalo manualmente."
            );

            return;
        }

        Log.d(
                ETIQUETA_LOG,
                "Bluetooth activado correctamente"
        );

        // Obtenemos escáner BLE
        elEscanner = bluetoothAdapter.getBluetoothLeScanner();

        if (elEscanner == null) {

            Log.d(
                    ETIQUETA_LOG,
                    "ERROR: no se ha podido obtener el escáner BLE"
            );

            return;
        }

        Log.d(
                ETIQUETA_LOG,
                "Escáner BLE preparado correctamente"
        );
    }


    // ------------------------------------------------------------------
    // COMPROBAR QUE PODEMOS ESCANEAR
    // ------------------------------------------------------------------

    private boolean escanerPreparado() {

        if (!tengoPermisosBluetooth()) {

            Log.d(
                    ETIQUETA_LOG,
                    "No tenemos permisos Bluetooth"
            );

            pedirPermisosBluetooth();

            return false;
        }

        if (bluetoothAdapter == null || elEscanner == null) {

            inicializarBlueTooth();

            if (elEscanner == null) {
                return false;
            }
        }

        return true;
    }


    // ------------------------------------------------------------------
    // BUSCAR TODOS LOS DISPOSITIVOS BLE
    // ------------------------------------------------------------------

    private void buscarTodosLosDispositivosBTLE() {

        Log.d(
                ETIQUETA_LOG,
                "buscarTodosLosDispositivosBTLE(): empieza"
        );

        if (!escanerPreparado()) {
            return;
        }

        // Si ya había un escaneo, lo detenemos
        detenerBusquedaDispositivosBTLE();

        callbackDelEscaneo = new ScanCallback() {

            @Override
            public void onScanResult(
                    int callbackType,
                    ScanResult resultado
            ) {

                super.onScanResult(
                        callbackType,
                        resultado
                );

                mostrarInformacionDispositivoBTLE(
                        resultado
                );
            }


            @Override
            public void onBatchScanResults(
                    List<ScanResult> results
            ) {

                super.onBatchScanResults(results);

                for (ScanResult resultado : results) {

                    mostrarInformacionDispositivoBTLE(
                            resultado
                    );
                }
            }


            @Override
            public void onScanFailed(int errorCode) {

                super.onScanFailed(errorCode);

                Log.d(
                        ETIQUETA_LOG,
                        "ERROR escaneando BLE. Código = "
                                + errorCode
                );
            }
        };


        ScanSettings settings =
                new ScanSettings.Builder()
                        .setScanMode(
                                ScanSettings.SCAN_MODE_LOW_LATENCY
                        )
                        .build();


        Log.d(
                ETIQUETA_LOG,
                "Empezamos a buscar todos los dispositivos BLE"
        );

        elEscanner.startScan(
                null,
                settings,
                callbackDelEscaneo
        );
    }


    // ------------------------------------------------------------------
    // BUSCAR SOLO NUESTRO DISPOSITIVO
    // ------------------------------------------------------------------

    private void buscarEsteDispositivoBTLE(
            final String dispositivoBuscado
    ) {

        Log.d(
                ETIQUETA_LOG,
                "buscarEsteDispositivoBTLE(): "
                        + dispositivoBuscado
        );

        if (!escanerPreparado()) {
            return;
        }

        // Si había un escaneo anterior lo paramos
        detenerBusquedaDispositivosBTLE();


        callbackDelEscaneo = new ScanCallback() {

            @Override
            public void onScanResult(
                    int callbackType,
                    ScanResult resultado
            ) {

                super.onScanResult(
                        callbackType,
                        resultado
                );

                Log.d(
                        ETIQUETA_LOG,
                        "Encontrado dispositivo buscado"
                );

                mostrarInformacionDispositivoBTLE(
                        resultado
                );
            }


            @Override
            public void onBatchScanResults(
                    List<ScanResult> results
            ) {

                super.onBatchScanResults(results);

                for (ScanResult resultado : results) {

                    mostrarInformacionDispositivoBTLE(
                            resultado
                    );
                }
            }


            @Override
            public void onScanFailed(int errorCode) {

                super.onScanFailed(errorCode);

                Log.d(
                        ETIQUETA_LOG,
                        "ERROR buscando "
                                + dispositivoBuscado
                                + ". Código = "
                                + errorCode
                );
            }
        };


        // Creamos filtro por nombre
        ScanFilter filtro =
                new ScanFilter.Builder()
                        .setDeviceName(dispositivoBuscado)
                        .build();


        List<ScanFilter> filtros =
                new ArrayList<>();

        filtros.add(filtro);


        // Escaneo rápido
        ScanSettings settings =
                new ScanSettings.Builder()
                        .setScanMode(
                                ScanSettings.SCAN_MODE_LOW_LATENCY
                        )
                        .build();


        Log.d(
                ETIQUETA_LOG,
                "Empezamos a escanear buscando: "
                        + dispositivoBuscado
        );


        elEscanner.startScan(
                filtros,
                settings,
                callbackDelEscaneo
        );
    }


    // ------------------------------------------------------------------
    // MOSTRAR DATOS RECIBIDOS
    // ------------------------------------------------------------------

    private void mostrarInformacionDispositivoBTLE(
            ScanResult resultado
    ) {

        if (resultado == null) {
            return;
        }

        if (resultado.getScanRecord() == null) {

            Log.d(
                    ETIQUETA_LOG,
                    "ScanRecord es null. Ignoramos trama."
            );

            return;
        }


        byte[] bytes =
                resultado.getScanRecord().getBytes();


        if (bytes == null) {
            return;
        }


        // Trama del profesor necesita al menos 30 bytes
        if (bytes.length < 30) {

            Log.d(
                    ETIQUETA_LOG,
                    "Trama demasiado corta: "
                            + bytes.length
                            + " bytes"
            );

            return;
        }


        BluetoothDevice bluetoothDevice =
                resultado.getDevice();


        int rssi =
                resultado.getRssi();


        String nombre = null;


        if (tengoPermisosBluetooth()) {

            nombre =
                    bluetoothDevice.getName();
        }


        Log.d(
                ETIQUETA_LOG,
                "****************************************************"
        );

        Log.d(
                ETIQUETA_LOG,
                "****** DISPOSITIVO DETECTADO BTLE ******************"
        );

        Log.d(
                ETIQUETA_LOG,
                "****************************************************"
        );

        Log.d(
                ETIQUETA_LOG,
                "nombre = " + nombre
        );


        if (tengoPermisosBluetooth()) {

            Log.d(
                    ETIQUETA_LOG,
                    "dirección = "
                            + bluetoothDevice.getAddress()
            );
        }


        Log.d(
                ETIQUETA_LOG,
                "RSSI = " + rssi
        );


        Log.d(
                ETIQUETA_LOG,
                "bytes ("
                        + bytes.length
                        + ") = "
                        + Utilidades.bytesToHexString(bytes)
        );


        // Convertimos los bytes a trama iBeacon
        TramaIBeacon tib;

        try {

            tib =
                    new TramaIBeacon(bytes);

        } catch (Exception e) {

            Log.d(
                    ETIQUETA_LOG,
                    "ERROR interpretando trama iBeacon: "
                            + e.getMessage()
            );

            return;
        }


        int major =
                Utilidades.bytesToIntOK(
                        tib.getMajor()
                );


        int minor =
                Utilidades.bytesToIntOK(
                        tib.getMinor()
                );


        Log.d(
                ETIQUETA_LOG,
                "----------------------------------------------------"
        );


        Log.d(
                ETIQUETA_LOG,
                "prefijo = "
                        + Utilidades.bytesToHexString(
                        tib.getPrefijo()
                )
        );


        Log.d(
                ETIQUETA_LOG,
                "advFlags = "
                        + Utilidades.bytesToHexString(
                        tib.getAdvFlags()
                )
        );


        Log.d(
                ETIQUETA_LOG,
                "advHeader = "
                        + Utilidades.bytesToHexString(
                        tib.getAdvHeader()
                )
        );


        Log.d(
                ETIQUETA_LOG,
                "companyID = "
                        + Utilidades.bytesToHexString(
                        tib.getCompanyID()
                )
        );


        Log.d(
                ETIQUETA_LOG,
                "iBeacon type = "
                        + Integer.toHexString(
                        tib.getiBeaconType() & 0xFF
                )
        );


        Log.d(
                ETIQUETA_LOG,
                "iBeacon length = "
                        + (tib.getiBeaconLength() & 0xFF)
        );


        Log.d(
                ETIQUETA_LOG,
                "UUID HEX = "
                        + Utilidades.bytesToHexString(
                        tib.getUUID()
                )
        );


        Log.d(
                ETIQUETA_LOG,
                "UUID TEXTO = "
                        + Utilidades.bytesToString(
                        tib.getUUID()
                )
        );


        Log.d(
                ETIQUETA_LOG,
                "MAJOR = "
                        + major
        );


        Log.d(
                ETIQUETA_LOG,
                "MINOR = "
                        + minor
        );


        Log.d(
                ETIQUETA_LOG,
                "txPower = "
                        + tib.getTxPower()
        );


        Log.d(
                ETIQUETA_LOG,
                "****************************************************"
        );
    }


    // ------------------------------------------------------------------
    // DETENER ESCANEO
    // ------------------------------------------------------------------

    private void detenerBusquedaDispositivosBTLE() {

        if (callbackDelEscaneo == null) {
            return;
        }

        if (elEscanner == null) {
            return;
        }

        if (!tengoPermisosBluetooth()) {
            return;
        }


        elEscanner.stopScan(
                callbackDelEscaneo
        );


        callbackDelEscaneo = null;


        Log.d(
                ETIQUETA_LOG,
                "Escaneo BLE detenido"
        );
    }


    // ------------------------------------------------------------------
    // BOTÓN BUSCAR TODOS
    // ------------------------------------------------------------------

    public void botonBuscarDispositivosBTLEPulsado(
            View v
    ) {

        Log.d(
                ETIQUETA_LOG,
                "Botón buscar dispositivos BLE pulsado"
        );

        buscarTodosLosDispositivosBTLE();
    }


    // ------------------------------------------------------------------
    // BOTÓN BUSCAR NUESTRO DISPOSITIVO
    // ------------------------------------------------------------------

    public void botonBuscarNuestroDispositivoBTLEPulsado(
            View v
    ) {

        Log.d(
                ETIQUETA_LOG,
                "Botón buscar nuestro dispositivo BLE pulsado"
        );


        buscarEsteDispositivoBTLE(
                NOMBRE_BEACON
        );
    }


    // ------------------------------------------------------------------
    // BOTÓN DETENER
    // ------------------------------------------------------------------

    public void botonDetenerBusquedaDispositivosBTLEPulsado(
            View v
    ) {

        Log.d(
                ETIQUETA_LOG,
                "Botón detener búsqueda BLE pulsado"
        );

        detenerBusquedaDispositivosBTLE();
    }


    // ------------------------------------------------------------------
    // ON CREATE
    // ------------------------------------------------------------------

    @Override
    protected void onCreate(
            Bundle savedInstanceState
    ) {

        super.onCreate(savedInstanceState);

        setContentView(
                R.layout.activity_main
        );


        Log.d(
                ETIQUETA_LOG,
                "onCreate(): empieza"
        );


        inicializarBlueTooth();


        Log.d(
                ETIQUETA_LOG,
                "onCreate(): termina"
        );
    }


    // ------------------------------------------------------------------
    // RESULTADO DE PERMISOS
    // ------------------------------------------------------------------

    @Override
    public void onRequestPermissionsResult(
            int requestCode,
            String[] permissions,
            int[] grantResults
    ) {

        super.onRequestPermissionsResult(
                requestCode,
                permissions,
                grantResults
        );


        if (
                requestCode
                        == CODIGO_PETICION_PERMISOS
        ) {

            boolean todosConcedidos = true;


            if (grantResults.length == 0) {

                todosConcedidos = false;

            } else {

                for (int resultado : grantResults) {

                    if (
                            resultado
                                    != PackageManager.PERMISSION_GRANTED
                    ) {

                        todosConcedidos = false;
                        break;
                    }
                }
            }


            if (todosConcedidos) {

                Log.d(
                        ETIQUETA_LOG,
                        "Permisos Bluetooth concedidos"
                );

                // Ahora que tenemos permisos,
                // inicializamos Bluetooth otra vez
                inicializarBlueTooth();

            } else {

                Log.d(
                        ETIQUETA_LOG,
                        "Permisos Bluetooth NO concedidos"
                );
            }
        }
    }


    // ------------------------------------------------------------------
    // AL CERRAR LA ACTIVITY
    // ------------------------------------------------------------------

    @Override
    protected void onDestroy() {

        detenerBusquedaDispositivosBTLE();

        super.onDestroy();
    }
}